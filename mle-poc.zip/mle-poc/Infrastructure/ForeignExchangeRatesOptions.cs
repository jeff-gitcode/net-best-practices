namespace Infrastructure;

public class ForeignExchangeRatesOptions
{
    public const string SectionName = "ForeignExchangeRates";

    public string BaseUrl { get; set; } = null!;
    public string UserId { get; set; } = null!;
    public string Password { get; set; } = null!;

    public string CertificatePath { get; set; } = null!;

    public string CertificatePassword { get; set; } = null!;

}

public class JWEOptions
{
    public const string SectionName = "JWE";
    public string KeyId { get; set; } = null!;

    public string MleClientPrivateKeyPath { get; set; } = null!;

    public string MleServerPublicKeyPath { get; set; } = null!;

}