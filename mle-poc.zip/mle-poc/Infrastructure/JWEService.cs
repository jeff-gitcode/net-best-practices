﻿using Jose;
using Microsoft.Extensions.Options;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace Infrastructure
{
    public interface IJWEService
    {
        public string GetEncryptedPayload(String requestBody);

        public string GetDecryptedPayload(String encryptedPayload);
    }

    public class JWEService(IOptionsMonitor<JWEOptions> options) : IJWEService
    {
        public string GetDecryptedPayload(string encryptedPayload)
        {
            var jsonPayload = Newtonsoft.Json.JsonConvert.DeserializeObject<EncryptedPayload>(
                encryptedPayload
            );
            return JWT.Decode(
                jsonPayload!.encData,
                ImportPrivateKey(options.CurrentValue.MleClientPrivateKeyPath)
            );
        }

        public string GetEncryptedPayload(string requestBody)
        {
            var clientCertificate = new X509Certificate2(
                options.CurrentValue.MleServerPublicKeyPath
            ).GetRSAPublicKey();
            DateTime now = DateTime.UtcNow;
            long unixTimeMilliseconds = new DateTimeOffset(now).ToUnixTimeMilliseconds();
            IDictionary<string, object> extraHeaders = new Dictionary<string, object>
            {
                { "kid", options.CurrentValue.KeyId },
                { "iat", unixTimeMilliseconds }
            };
            string token = JWT.Encode(
                requestBody,
                clientCertificate,
                JweAlgorithm.RSA_OAEP_256,
                JweEncryption.A128GCM,
                null,
                extraHeaders
            );
            return "{\"encData\":\"" + token + "\"}";
        }

        private RSA ImportPrivateKey(string privateKeyFile)
        {
            var pemValue = System.Text.Encoding.Default.GetString(
                File.ReadAllBytes(privateKeyFile)
            );
            var pr = new PemReader(new StringReader(pemValue));
            var keyPair = (AsymmetricCipherKeyPair)pr.ReadObject();
            var rsaParams = DotNetUtilities.ToRSAParameters(
                (RsaPrivateCrtKeyParameters)keyPair.Private
            );

            var rsa = RSA.Create();
            rsa.ImportParameters(rsaParams);

            return rsa;
        }
    }

    public class EncryptedPayload
    {
        public required string encData { get; set; }
    }
}
