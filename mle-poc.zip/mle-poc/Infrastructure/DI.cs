﻿using Application.Contract;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Polly;
using Polly.Extensions.Http;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Infrastructure;

public static class DI
{
    public static IServiceCollection RegisterInfrastructureServices(
        this IServiceCollection services,
        IConfiguration configuration
    )
    {
        services.Configure<JWEOptions>(
            configuration.GetSection(JWEOptions.SectionName)
        );

        var jWEOptions = configuration
            .GetSection(JWEOptions.SectionName)
            .Get<JWEOptions>();

        services.AddTransient<IJWEService, JWEService>();

        services.Configure<ForeignExchangeRatesOptions>(
            configuration.GetSection(ForeignExchangeRatesOptions.SectionName)
        );

        var foreignExchangeRatesOptions = configuration
            .GetSection(ForeignExchangeRatesOptions.SectionName)
            .Get<ForeignExchangeRatesOptions>();

        services
            .AddHttpClient<IForeignExchangeRatesService, ForeignExchangeRatesService>(
                ConfigClient(foreignExchangeRatesOptions!, jWEOptions!)
            )
            .ConfigurePrimaryHttpMessageHandler(() => CreateHttpClientHandler(foreignExchangeRatesOptions))
            .SetHandlerLifetime(TimeSpan.FromMinutes(5))  //Set lifetime to five minutes
            .AddPolicyHandler(GetRetryPolicy());

        return services;
    }

    private static HttpClientHandler CreateHttpClientHandler(ForeignExchangeRatesOptions? options)
    {
        var certificate = new X509Certificate2(
            options!.CertificatePath,
            options.CertificatePassword
        );

        var handler = new HttpClientHandler();
        handler.ClientCertificates.Add(certificate);
        return handler;
    }

    private static Action<HttpClient> ConfigClient(ForeignExchangeRatesOptions foreignExchangeRatesOptions, JWEOptions jWEOptions)
    {
        return client =>
        {
            client.BaseAddress = new Uri(foreignExchangeRatesOptions.BaseUrl);
            client.DefaultRequestHeaders.Add(
                "Authorization",
                GetBasicAuthHeader(foreignExchangeRatesOptions.UserId, foreignExchangeRatesOptions.Password)
            );
            client.DefaultRequestHeaders.Add("ex-correlation-id", GetCorrelationId());
            client.DefaultRequestHeaders.Add("keyId", jWEOptions.KeyId);

            client.DefaultRequestHeaders.Add("ContentType", "applicaiton/json");
            client.DefaultRequestHeaders.Add("Accept", "applicaiton/json");
        };
    }

    public static string GetCorrelationId()
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        var random = new Random();
        return new string(
                Enumerable.Repeat(chars, 12).Select(s => s[random.Next(s.Length)]).ToArray()
            ) + "_SC";
    }

    public static string GetBasicAuthHeader(string userId, string password)
    {
        string authString = userId + ":" + password;
        var authStringBytes = Encoding.UTF8.GetBytes(authString);
        string authHeaderString = Convert.ToBase64String(authStringBytes);
        return "Basic " + authHeaderString;
    }

    static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
    {
        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .OrResult(msg => msg.StatusCode == System.Net.HttpStatusCode.NotFound)
            .WaitAndRetryAsync(6, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2,
                                                                        retryAttempt)));
    }
}
