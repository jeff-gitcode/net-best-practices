using Application;
using Application.Contract;
using Application.Handlers;
using Microsoft.Extensions.Logging;
using System.Text;
using System.Text.Json;

namespace Infrastructure
{
    public class ForeignExchangeRatesService : IForeignExchangeRatesService
    {
        private readonly HttpClient _httpClient;
        private readonly IJWEService _jweService;
        private readonly ILogger<ForeignExchangeRatesService> _logger;

        public ForeignExchangeRatesService(
            HttpClient httpClient,
            IJWEService jweService,
            ILogger<ForeignExchangeRatesService> logger
        )
        {
            _httpClient = httpClient;
            _jweService = jweService;
            _logger = logger;
        }

        public async Task<ForeignExchangeRatesResponse> GetForeignExchangeRates(
            ForeignExchangeRatesQuery query
        )
        {
            // Implementation
            // await Task.CompletedTask;
            // return new ForeignExchangeRatesResponse(
            //     "rateProductCode",
            //     "destinationCurrencyCode",
            //     "quoteIdExpiryDateTime",
            //     "sourceCurrencyCode",
            //     "conversionRate",
            //     "quoteId"
            // );

            var options = new JsonSerializerOptions
            {
                WriteIndented = false,
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            };
            var jsonPayload = JsonSerializer.Serialize(query, options);

            _logger.LogInformation(jsonPayload);

            var encryptedPayload = _jweService.GetEncryptedPayload(jsonPayload);
            var endpoint = "forexrates/v2/foreignexchangerates";

            try
            {
                var response = await _httpClient.PostAsync(
                    endpoint,
                    new StringContent(encryptedPayload, Encoding.UTF8, "application/json")
                );

                response.EnsureSuccessStatusCode();

                var responseBody = await response.Content.ReadAsStringAsync();
                var decryptedPayload = _jweService.GetDecryptedPayload(responseBody);

                _logger.LogInformation(decryptedPayload);
                return JsonSerializer.Deserialize<ForeignExchangeRatesResponse>(decryptedPayload)!;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
