using Application.Handlers;
using Infrastructure;
using MediatR;
using WebApi;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();

builder.Services.AddExceptionHandler<GlobalExceptionHandler>().AddProblemDetails();

// Add services to the container.
// builder.Services.Configure<ForeignExchangeRatesOptions>(builder.Configuration.GetSection(ForeignExchangeRatesOptions.ForeignExchangeRates));
builder.Services.Configure<ForeignExchangeRatesOptions>(
    builder.Configuration.GetSection(ForeignExchangeRatesOptions.SectionName)
);

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder
    .Services.RegisterInfrastructureServices(builder.Configuration)
    .AddMediatR(config =>
        config.RegisterServicesFromAssemblies(AppDomain.CurrentDomain.GetAssemblies())
    );

var app = builder.Build();

app.MapDefaultEndpoints();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseExceptionHandler();

app.UseHttpsRedirection();

app.MapPost(
        "/foreignexchangerates",
        async (IMediator mediator, ForeignExchangeRatesQuery query, CancellationToken ct) =>
        {
            query = new ForeignExchangeRatesQuery(1002, "BANK", "USD", "EUR", true);

            var response = await mediator.Send(query);

            return response;
        }
    )
    .WithName("ForeignExchangeRates")
    .WithOpenApi();

//var summaries = new[]
//{
//    "Freezing",
//    "Bracing",
//    "Chilly",
//    "Cool",
//    "Mild",
//    "Warm",
//    "Balmy",
//    "Hot",
//    "Sweltering",
//    "Scorching"
//};

//app.MapGet("/weatherforecast", () =>
//{
//    var forecast = Enumerable.Range(1, 5).Select(index =>
//        new WeatherForecast
//        (
//            DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
//            Random.Shared.Next(-20, 55),
//            summaries[Random.Shared.Next(summaries.Length)]
//        ))
//        .ToArray();
//    return forecast;
//})
//.WithName("GetWeatherForecast")
//.WithOpenApi();

app.Run();

public partial class Program { }

public record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}

public record TestRequest(string test1);
