﻿using Application.Handlers;

namespace Application.Contract
{
    public interface IForeignExchangeRatesService
    {
        public Task<ForeignExchangeRatesResponse> GetForeignExchangeRates(ForeignExchangeRatesQuery query);
    }
}
