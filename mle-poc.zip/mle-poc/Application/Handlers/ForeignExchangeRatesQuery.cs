﻿using Application.Contract;
using MediatR;

namespace Application.Handlers
{
    public record ForeignExchangeRatesQuery(
        int initiatingPartyId,
        string rateProductCode,
        string destinationCurrencyCode,
        string sourceCurrencyCode,
        bool quoteIdRequired
    ) : IRequest<ForeignExchangeRatesResponse>
    { }

    public class ForeignExchangeRatesHandler(
        IForeignExchangeRatesService foreignExchangeRatesService
    ) : IRequestHandler<ForeignExchangeRatesQuery, ForeignExchangeRatesResponse>
    {
        public async Task<ForeignExchangeRatesResponse> Handle(
            ForeignExchangeRatesQuery request,
            CancellationToken cancellationToken
        )
        {
            // Implementation
            return await foreignExchangeRatesService.GetForeignExchangeRates(request);
        }
    }
}
