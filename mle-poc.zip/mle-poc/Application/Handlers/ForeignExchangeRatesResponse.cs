﻿namespace Application;

public record ForeignExchangeRatesResponse(
    decimal conversionRate,
    string rateProductCode,
    string sourceCurrencyCode,
    string destinationCurrencyCode,
    long quoteId,
    string quoteIdExpiryDateTime
);
